<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ServiceProduct;

class ServiceProductSeeder extends Seeder
{
    public function run(): void
    {
        ServiceProduct::factory()->count(5)->create();
    }
}
