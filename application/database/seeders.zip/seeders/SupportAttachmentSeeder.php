<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SupportAttachment;

class SupportAttachmentSeeder extends Seeder
{
    public function run(): void
    {
        SupportAttachment::factory()->count(5)->create();
    }
}
