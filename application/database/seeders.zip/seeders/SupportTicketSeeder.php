<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SupportTicket;

class SupportTicketSeeder extends Seeder
{
    public function run(): void
    {
        SupportTicket::factory()->count(5)->create();
    }
}
