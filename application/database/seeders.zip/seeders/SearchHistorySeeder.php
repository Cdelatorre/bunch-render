<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SearchHistory;

class SearchHistorySeeder extends Seeder
{
    public function run(): void
    {
        SearchHistory::factory()->count(5)->create();
    }
}
