<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\PasswordReset;

class PasswordResetSeeder extends Seeder
{
    public function run(): void
    {
        PasswordReset::factory()->count(5)->create();
    }
}
