<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\WithdrawMethod;

class WithdrawMethodSeeder extends Seeder
{
    public function run(): void
    {
        WithdrawMethod::factory()->count(5)->create();
    }
}
