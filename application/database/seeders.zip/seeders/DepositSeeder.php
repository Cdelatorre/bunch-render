<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Deposit;

class DepositSeeder extends Seeder
{
    public function run(): void
    {
        Deposit::factory()->count(5)->create();
    }
}
