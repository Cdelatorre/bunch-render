<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\CategoryProduct;

class CategoryProductSeeder extends Seeder
{
    public function run(): void
    {
        CategoryProduct::factory()->count(5)->create();
    }
}
