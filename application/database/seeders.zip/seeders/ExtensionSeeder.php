<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Extension;

class ExtensionSeeder extends Seeder
{
    public function run(): void
    {
        Extension::factory()->count(5)->create();
    }
}
