<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\AdminPasswordReset;

class AdminPasswordResetSeeder extends Seeder
{
    public function run(): void
    {
        AdminPasswordReset::factory()->count(5)->create();
    }
}
