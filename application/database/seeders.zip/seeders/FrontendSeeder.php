<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Frontend;

class FrontendSeeder extends Seeder
{
    public function run(): void
    {
        Frontend::factory()->count(5)->create();
    }
}
