<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\AdminNotification;

class AdminNotificationSeeder extends Seeder
{
    public function run(): void
    {
        AdminNotification::factory()->count(5)->create();
    }
}
