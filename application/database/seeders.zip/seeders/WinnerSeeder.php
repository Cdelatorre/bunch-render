<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Winner;

class WinnerSeeder extends Seeder
{
    public function run(): void
    {
        Winner::factory()->count(5)->create();
    }
}
