<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SupportMessage;

class SupportMessageSeeder extends Seeder
{
    public function run(): void
    {
        SupportMessage::factory()->count(5)->create();
    }
}
