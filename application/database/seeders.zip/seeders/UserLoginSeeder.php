<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\UserLogin;

class UserLoginSeeder extends Seeder
{
    public function run(): void
    {
        UserLogin::factory()->count(5)->create();
    }
}
