<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Withdrawal;

class WithdrawalSeeder extends Seeder
{
    public function run(): void
    {
        Withdrawal::factory()->count(5)->create();
    }
}
