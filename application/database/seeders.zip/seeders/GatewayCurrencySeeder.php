<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\GatewayCurrency;

class GatewayCurrencySeeder extends Seeder
{
    public function run(): void
    {
        GatewayCurrency::factory()->count(5)->create();
    }
}
