<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            AdminNotificationSeeder::class,
            AdminPasswordResetSeeder::class,
            CategoryProductSeeder::class,
            CategorySeeder::class,
            DepositSeeder::class,
            ExtensionSeeder::class,
            FormSeeder::class,
            FrontendSeeder::class,
            GatewayCurrencySeeder::class,
            GatewaySeeder::class,
            GeneralSettingSeeder::class,
            ImageSeeder::class,
            LanguageSeeder::class,
            NotificationLogSeeder::class,
            NotificationTemplateSeeder::class,
            PageSeeder::class,
            PasswordResetSeeder::class,
            ProductSeeder::class,
            ProductUserSeeder::class,
            ReviewSeeder::class,
            SearchHistorySeeder::class,
            ServiceProductSeeder::class,
            ServicesSeeder::class,
            SubscriberSeeder::class,
            SupportAttachmentSeeder::class,
            SupportMessageSeeder::class,
            SupportTicketSeeder::class,
            TransactionSeeder::class,
            UserLoginSeeder::class,
            ViewedHistorySeeder::class,
            WinnerSeeder::class,
            WishlistSeeder::class,
            WithdrawalSeeder::class,
            WithdrawMethodSeeder::class,
        ]);
    }
}
