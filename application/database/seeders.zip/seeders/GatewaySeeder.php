<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Gateway;

class GatewaySeeder extends Seeder
{
    public function run(): void
    {
        Gateway::factory()->count(5)->create();
    }
}
