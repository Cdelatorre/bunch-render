<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\NotificationLog;

class NotificationLogSeeder extends Seeder
{
    public function run(): void
    {
        NotificationLog::factory()->count(5)->create();
    }
}
