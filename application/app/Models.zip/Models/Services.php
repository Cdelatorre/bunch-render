<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
    use HasFactory;

    public function products() {
        return $this->hasMany(ServiceProduct::class, 'id', 'service_id'); // Specify foreign key
    }

    public function parent() {
        return $this->belongsTo(Services::class, 'parent'); // Specify foreign key
    }

    public function children() {
        return $this->hasMany(Services::class, 'parent'); // Specify foreign key
    }

    public function statusBadge(): Attribute
    {
        return new Attribute(
            get:fn () => $this->badgeData(),
        );
    }

    public function badgeData(){
        $html = '';
        if($this->status == 0){
            $html = '<span class="badge badge--danger">'.trans('Inactive').'</span>';
        }
        elseif($this->status == 1){
            $html = '<span class="badge badge--success">'.trans('Active').'</span>';
        }

        return $html;
    }
}
